<?php 
    session_start();
    // $_SESSION['user_] -> user's all info