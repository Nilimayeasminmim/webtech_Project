<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Related Products</title>
    <link rel="stylesheet" href="css/viewAllStyles.css" />
</head>

<body>

    <a href="book-page.php">Back</a>
    <?php require_once ('navbar.php') ?>


    <table class="related-products-table" id="related-products-table">
        <tr>
            <td>
                <h2>Related Products</h2>
            </td>
        </tr>
        <tr>
            <td>
                Title: <br>
                Author Name: <br>
                <img src="" alt="x"><br>
                Taka:
            </td>
        </tr>
        <tr>
            <td>
                Title: <br>
                Author Name: <br>
                <img src="" alt="x"><br>
                Taka:
            </td>
        </tr>
    </table>
    <?php require_once ('footer.php') ?>
</body>

</html>